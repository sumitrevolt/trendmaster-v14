"""TradingView webhook receiver — stdlib HTTP server, zero new deps.

Listens on TV_WEBHOOK_HOST:TV_WEBHOOK_PORT for POSTs from a TradingView
alert (Premium plan, "Webhook URL" feature). Validates the shared secret,
parses the alert body, and hands off to `tv_executor.write_tv_signal()`
which writes the EA-readable signal JSON.

Endpoints:
    GET  /health    → 200 {"status":"ok","ts":...}    (for ngrok / monitor)
    POST /tv-signal → see body schema below

Body schema (paste this template into the TV alert "Message" field):
    {
      "secret":"YOUR_SECRET",
      "symbol":"{{ticker}}",
      "direction":"{{strategy.order.action}}",
      "price":{{close}},
      "tv_strategy":"{{strategy.order.comment}}",
      "tv_alert_ts":{{timenow}}
    }

Strategy alerts give you `{{strategy.order.action}}` = buy/sell. For
plain indicator alerts you can hardcode the direction per-alert and use:
    {"secret":"...","symbol":"{{ticker}}","direction":"buy","price":{{close}}}

Run:
    python -m ai_trading_agents.tv_webhook_receiver
or via:
    start_tv_webhook.cmd

Environment (config/.env):
    TV_WEBHOOK_SECRET=<32+ char random string — required>
    TV_WEBHOOK_HOST=127.0.0.1   (default; bind to localhost — tunnel exposes)
    TV_WEBHOOK_PORT=5005        (default)

Security:
* Bind to 127.0.0.1 by default and tunnel to TV via ngrok / Cloudflare.
  Never bind 0.0.0.0 without TLS — that's the broker account on the line.
* Shared secret check is `hmac.compare_digest` (constant-time).
* Reject any payload > 4 KiB (TV alerts are tiny — anything bigger is junk).
* Symbol whitelist enforced inside `tv_executor.write_tv_signal`.
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict

# Plain parent.parent — see CLAUDE.md "Brain path resolution rule"
_HERE = Path(__file__).parent
_ROOT = _HERE.parent

# ─── .env loading (same pattern telegram_notifier.py uses) ────────────────
try:
    from dotenv import load_dotenv  # type: ignore

    for _cand in (_ROOT / ".env", _ROOT / "config" / ".env", _HERE / ".env"):
        if _cand.exists():
            load_dotenv(_cand, override=False)
except ImportError:
    pass

# Logging — file + stderr. Same logs/ dir convention as the brain.
_LOG_DIR = _ROOT / "logs"
_LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(_LOG_DIR / "tv_webhook.log", encoding="utf-8"),
        # NOTE: removed StreamHandler(sys.stderr) — when launched detached
        # via `cmd /c start /MIN`, stderr's parent console can disappear
        # after the launching shell exits, causing the receiver to crash
        # on the first log write (broken pipe). FileHandler alone is safe.
    ],
)
logger = logging.getLogger("tv_webhook")

# Lazy import — keeps a missing config from blowing up at import time.
try:
    from ai_trading_agents.tv_executor import write_tv_signal
except Exception as e:  # pragma: no cover
    logger.error("Cannot import tv_executor: %s", e)
    raise


# ─── config ───────────────────────────────────────────────────────────────
SECRET = os.getenv("TV_WEBHOOK_SECRET", "").strip()
HOST = os.getenv("TV_WEBHOOK_HOST", "127.0.0.1").strip()
PORT = int(os.getenv("TV_WEBHOOK_PORT", "5005"))
MAX_BODY_BYTES = 4096  # TV alerts are tiny; anything bigger is junk

# In-memory dedup + lightweight runtime metrics for /status endpoint.
import threading

_DEDUP_LOCK = threading.Lock()
_DEDUP_CACHE: Dict[str, float] = {}
DEDUP_WINDOW_S = float(os.getenv("TV_WEBHOOK_DEDUP_WINDOW_S", "20"))

_METRICS: Dict[str, int] = {
    "started_at": int(time.time()),
    "requests_total": 0,
    "auth_fails": 0,
    "rejected": 0,
    "duplicates": 0,
    "writes_ok": 0,
}


# ─── handler ──────────────────────────────────────────────────────────────
class TVHandler(BaseHTTPRequestHandler):
    # Silence the default request log — we log structured records ourselves.
    def log_message(self, fmt, *args):  # noqa: A003 (override stdlib)
        return

    def _send(self, status: int, body: dict) -> None:
        raw = json.dumps(body, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    # --- GET /health and /status -----------------------------------------
    def do_GET(self):  # noqa: N802 (stdlib name)
        path = self.path.split("?", 1)[0]
        if path == "/health":
            self._send(200, {"status": "ok", "ts": int(time.time())})
            return
        if path == "/status":
            uptime = int(time.time()) - _METRICS["started_at"]
            self._send(
                200,
                {
                    "status": "ok",
                    "uptime_s": uptime,
                    "metrics": dict(_METRICS),
                    "dedup_window_s": DEDUP_WINDOW_S,
                    "ts": int(time.time()),
                },
            )
            return
        self._send(404, {"error": "not_found"})

    # --- POST /tv-signal --------------------------------------------------
    def do_POST(self):  # noqa: N802
        if self.path.split("?", 1)[0] != "/tv-signal":
            self._send(404, {"error": "not_found"})
            return

        # 1) read body (size-bounded)
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send(400, {"error": "bad_content_length"})
            return
        if content_length <= 0 or content_length > MAX_BODY_BYTES:
            self._send(413, {"error": "body_too_large_or_empty", "limit": MAX_BODY_BYTES})
            return
        try:
            raw = self.rfile.read(content_length)
        except Exception as e:
            logger.warning("read failed: %s", e)
            self._send(400, {"error": "read_failed"})
            return

        # 2) parse — try JSON first, fall back to text-format parser
        # (Rocket Prime indicator and similar paid invite-only indicators
        # don't let you customise the message; their default text is what
        # arrives. We extract symbol from query param ?symbol= or from any
        # token in the body that's in our SYMBOL_TO_TEAM whitelist, and
        # direction from "Buy/Sell Observation" / "buy"/"sell" keywords.)
        body_text = raw.decode("utf-8", errors="replace")
        body: dict = {}
        is_json = False
        try:
            obj = json.loads(body_text)
            if isinstance(obj, dict):
                body = obj
                is_json = True
        except json.JSONDecodeError:
            pass

        # 3) auth — accept secret from JSON body OR URL query (?secret=...)
        # so plain-text indicator messages can still be authenticated by
        # putting the secret in the webhook URL.
        if not SECRET:
            logger.error("TV_WEBHOOK_SECRET not set — refusing to accept signals")
            self._send(503, {"error": "secret_not_configured"})
            return
        provided = str(body.get("secret", "")) if is_json else ""
        if not provided and "?" in self.path:
            # try query param
            from urllib.parse import urlparse, parse_qs

            qs = parse_qs(urlparse(self.path).query)
            provided = (qs.get("secret") or [""])[0]
        if not hmac.compare_digest(str(provided), SECRET):
            _METRICS["auth_fails"] += 1
            logger.warning("auth fail from %s (json=%s)", self.client_address, is_json)
            self._send(401, {"error": "unauthorized"})
            return

        # 4) extract symbol + direction (+ optional timeframe metadata)
        if is_json:
            symbol = str(body.get("symbol", "")).upper().strip()
            direction = str(body.get("direction", body.get("action", "")))
            confidence = body.get("confidence")
            tv_strategy = body.get("tv_strategy") or body.get("strategy")
            tv_price = body.get("price") or body.get("tv_price")
            tv_alert_ts = body.get("tv_alert_ts") or body.get("ts")
            # TF: TradingView emits {{interval}} as "5", "60", "240", "D"
            # Accept any of the three common JSON keys.
            tv_timeframe = (
                body.get("tv_timeframe")
                or body.get("timeframe")
                or body.get("interval")
            )
        else:
            # Text-mode: use the email parser's symbol+direction extraction.
            # The "subject" we pass is the URL query (which contains ticker if
            # the user added &symbol={{ticker}} to their webhook URL); the
            # body is the raw indicator message.
            from urllib.parse import urlparse, parse_qs
            from ai_trading_agents.tv_email_receiver import (
                _extract_symbol,
                _extract_direction,
            )

            qs = parse_qs(urlparse(self.path).query)
            sym_hint = (qs.get("symbol") or [""])[0]
            symbol = (
                _extract_symbol(sym_hint, body_text)
                or _extract_symbol("", body_text)
                or ""
            )
            direction = _extract_direction(body_text) or ""
            confidence = None
            tv_strategy = "rocket_prime_text"
            tv_price = None
            tv_alert_ts = None
            # TF for text mode: ?tf=15 / ?interval=H1 query param.
            tv_timeframe = (qs.get("tf") or qs.get("interval") or [""])[0] or None
            # Debug: log full body when direction extraction fails (one-time).
            if not direction:
                try:
                    debug_path = _LOG_DIR / "tv_webhook_unparsed_bodies.log"
                    with open(debug_path, "a", encoding="utf-8") as df:
                        df.write(f"\n=== {time.strftime('%Y-%m-%dT%H:%M:%S')} sym={symbol!r} ===\n")
                        df.write(f"URL query: {self.path}\n")
                        df.write(f"Body ({len(body_text)} chars):\n")
                        df.write(body_text)
                        df.write("\n--- end body ---\n")
                except Exception:
                    pass
            # FALLBACK: when text parser can't determine direction (Rocket Prime
            # sends "#### SYMBOL ####" with no direction info), use direction
            # inference from MT5 prices. Rocket Prime's alert tells us WHEN to
            # look; local trend filter decides WHICH WAY.
            if not direction and symbol:
                try:
                    from ai_trading_agents.direction_inference import infer_direction
                    inferred, infer_meta = infer_direction(symbol, tv_timeframe or "M5")
                    if inferred in ("BUY", "SELL"):
                        direction = inferred.lower()
                        tv_strategy = "rocket_prime_inferred"
                        if infer_meta.get("confidence_strong"):
                            confidence = 0.85   # strong reversal pattern
                        elif infer_meta.get("weak_signal"):
                            confidence = 0.55   # mid-range, weak fallback
                        else:
                            confidence = 0.70   # decent reversal signal
                        logger.info(
                            "INFERRED %s for %s  pos_in_range=%s last3_pct=%s rsi=%s conf=%.2f",
                            inferred, symbol,
                            infer_meta.get("pos_in_range"),
                            infer_meta.get("last3_diff_pct"),
                            infer_meta.get("rsi"),
                            confidence,
                        )
                except Exception as e:
                    logger.warning("direction_inference failed for %s: %s", symbol, e)
            logger.info(
                "TEXT mode parse: symbol=%s direction=%s tf=%s body[:80]=%r",
                symbol,
                direction,
                tv_timeframe,
                body_text[:80],
            )

        # TV sometimes posts numbers as strings — coerce safely.
        if isinstance(tv_alert_ts, str):
            try:
                tv_alert_ts = int(float(tv_alert_ts))
            except ValueError:
                tv_alert_ts = None
        if isinstance(confidence, str):
            try:
                confidence = float(confidence)
            except ValueError:
                confidence = None

        # 5) dedup — skip duplicate (symbol, direction, timeframe) within
        # DEDUP_WINDOW_S. Per-TF dedup added 2026-05-04: previously M5 BUY
        # and H1 BUY firing within 20s would dedupe each other (same
        # (symbol,dir) key); now they're tracked separately so the operator
        # gets one trade per timeframe. If TF is missing/unknown, the key
        # falls back to "UNK" — which still dedupes legitimate same-second
        # duplicates from a single alert.
        if symbol and direction:
            norm_dir = direction.strip().upper()
            if norm_dir in {"LONG", "BULL"}:
                norm_dir = "BUY"
            elif norm_dir in {"SHORT", "BEAR"}:
                norm_dir = "SELL"
            # Provisional TF normaliser — mirrors tv_executor._normalise_timeframe
            # (kept inline so the receiver doesn't have to import it just for
            # the dedup key). Lower-case the raw, look up alias, fall back to UNK.
            tf_key = "UNK"
            if tv_timeframe is not None:
                _tf_raw = str(tv_timeframe).strip().lower()
                _tf_map = {
                    "1": "M1", "3": "M3", "5": "M5", "15": "M15", "30": "M30",
                    "45": "M45", "60": "H1", "120": "H2", "180": "H3", "240": "H4",
                    "d": "D1", "1d": "D1", "w": "W1", "1w": "W1",
                }
                tf_key = _tf_map.get(_tf_raw, _tf_raw.upper() or "UNK")
            cache_key = f"{symbol}:{norm_dir}:{tf_key}"
            now = time.time()
            with _DEDUP_LOCK:
                last = _DEDUP_CACHE.get(cache_key, 0.0)
                if now - last < DEDUP_WINDOW_S:
                    _METRICS["duplicates"] += 1
                    logger.info(
                        "dedup hit: %s within %.1fs (window=%.1fs)",
                        cache_key,
                        now - last,
                        DEDUP_WINDOW_S,
                    )
                    self._send(
                        200,
                        {"status": "duplicate_skipped", "symbol": symbol,
                         "direction": norm_dir, "timeframe": tf_key},
                    )
                    return
                _DEDUP_CACHE[cache_key] = now
                # Trim cache if it grows large. With 19 pairs × 4 TFs × 2 dirs
                # = 152 possible keys we'd realistically see, bumping the cap
                # from 200 → 400 keeps a couple of full cycles in memory.
                if len(_DEDUP_CACHE) > 400:
                    cutoff = now - max(DEDUP_WINDOW_S * 4, 60)
                    for k in [k for k, v in _DEDUP_CACHE.items() if v < cutoff]:
                        _DEDUP_CACHE.pop(k, None)

        _METRICS["requests_total"] += 1
        try:
            res = write_tv_signal(
                symbol=symbol,
                direction=direction,
                confidence=confidence,
                source="tradingview_webhook",
                tv_strategy=tv_strategy,
                tv_price=tv_price,
                tv_alert_ts=tv_alert_ts,
                tv_timeframe=tv_timeframe,
            )
        except Exception as e:
            logger.exception("write_tv_signal raised")
            self._send(500, {"error": "executor_failed", "detail": str(e)})
            return

        if not res.get("ok"):
            _METRICS["rejected"] += 1
            logger.warning(
                "rejected: symbol=%s direction=%s err=%s", symbol, direction, res.get("error")
            )
            # 422 = client-fixable (bad symbol / direction / staleness)
            self._send(422, {"error": "rejected", "detail": res.get("error"), "symbol": symbol})
            return

        _METRICS["writes_ok"] += 1
        logger.info(
            "TV→EA OK  symbol=%s dir=%s tf=%s conf=%.3f path=%s strategy=%s",
            symbol,
            res["payload"]["direction"],
            res["payload"].get("tv_timeframe") or res["payload"].get("tv_timeframe_raw") or "-",
            res["payload"]["confidence"],
            res["path"],
            tv_strategy,
        )
        self._send(
            200,
            {
                "status": "ok",
                "symbol": symbol,
                "direction": res["payload"]["direction"],
                "timeframe": res["payload"].get("tv_timeframe"),
                "confidence": res["payload"]["confidence"],
                "ts": res["payload"]["ts"],
            },
        )


def main() -> int:
    # Pre-flight: warn loudly if secret not set; refuse to bind 0.0.0.0
    # without one — that's a brokerage attack surface.
    if not SECRET:
        if HOST != "127.0.0.1":
            logger.error(
                "TV_WEBHOOK_SECRET not set AND HOST=%s — refusing to start. Set TV_WEBHOOK_SECRET in config/.env",
                HOST,
            )
            return 2
        logger.warning(
            "TV_WEBHOOK_SECRET not set — server will refuse all POSTs with 503. Set it in config/.env to accept signals."
        )

    addr = (HOST, PORT)
    httpd = ThreadingHTTPServer(addr, TVHandler)
    logger.info("TV webhook listening on http://%s:%d (secret_set=%s)", HOST, PORT, bool(SECRET))
    logger.info("  GET  /health")
    logger.info("  POST /tv-signal")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("shutdown requested")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
